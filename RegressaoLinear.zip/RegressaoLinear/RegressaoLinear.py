import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Função para calcular o coeficiente de correlação de Pearson
def pearson_correlation(x, y):
    # Calcula o coeficiente de correlação de Pearson entre dois conjuntos de dados x e y
    n = len(x)
    sum_x = np.sum(x)
    sum_y = np.sum(y)
    sum_xy = np.sum(x * y)
    sum_x_squared = np.sum(x ** 2)
    sum_y_squared = np.sum(y ** 2)
    
    numerator = (n * sum_xy) - (sum_x * sum_y)
    denominator = np.sqrt((n * sum_x_squared - sum_x ** 2) * (n * sum_y_squared - sum_y ** 2))
    
    correlation_coefficient = numerator / denominator
    
    return correlation_coefficient, sum_x, sum_y, sum_xy, sum_x_squared, sum_y_squared

# Função para calcular o coeficiente de determinação
def coefficient_of_determination(x, y):
    # Calcula o coeficiente de determinação (R²) entre dois conjuntos de dados x e y
    correlation_coefficient, sum_x, sum_y, sum_xy, sum_x_squared, sum_y_squared = pearson_correlation(x, y)
    r_squared = correlation_coefficient ** 2 * 100  # Converter para porcentagem
    return r_squared, sum_x, sum_y, sum_xy, sum_x_squared, sum_y_squared

# Função para calcular a reta de regressão
def regression_line(x, y):
    # Calcula a reta de regressão entre dois conjuntos de dados x e y
    correlation_coefficient, sum_x, sum_y, sum_xy, sum_x_squared, sum_y_squared = pearson_correlation(x, y)
    slope = correlation_coefficient * np.std(y) / np.std(x)  # Calcula o coeficiente angular
    intercept = np.mean(y) - slope * np.mean(x)  # Calcula o coeficiente linear
    return slope, intercept

# Função para formatar a equação da reta
def format_equation(slope, intercept):
    # Formata a equação da reta
    if intercept >= 0:
        equation = f"y = {slope:.2f}x + {intercept:.2f}"  # Se o intercepto for positivo
    else:
        equation = f"y = {slope:.2f}x - {-intercept:.2f}"  # Se o intercepto for negativo
    return equation

# Função principal
def main():
    # Solicitar ao usuário os valores de x separados por vírgula
    x_values = input("Insira os valores de X separados por vírgula: ")
    x = np.array([float(val.strip()) for val in x_values.split(",")])
    
    # Solicitar ao usuário os valores de y separados por vírgula
    y_values = input("Insira os valores de Y separados por vírgula: ")
    y = np.array([float(val.strip()) for val in y_values.split(",")])
    
    # Verificar se os arrays x e y têm o mesmo comprimento
    if len(x) != len(y):
        print("Erro: Os arrays de X e Y devem ter o mesmo comprimento.")
        return
    
    # Solicitar ao usuário o número de casas decimais
    decimal_places = int(input("Insira o número de casas decimais desejado: "))
    
    # Identificação das variáveis
    print("X: Variável independente")
    print("Y: Variável dependente")
    
    # Mostrar o sistema antes de resolver, com os valores das somas
    n = len(x)
    sum_x = np.sum(x)
    sum_y = np.sum(y)
    sum_xy = np.sum(x * y)
    sum_x_squared = np.sum(x ** 2)
    sum_y_squared = np.sum(y ** 2)
    
    print("\nSistema antes de resolver:")
    print("n =", n)
    print("Soma de X (ΣX):", sum_x)
    print("Soma de Y (ΣY):", sum_y)
    print("Soma de XY (ΣXY):", sum_xy)
    print("Soma de X² (ΣX²):", sum_x_squared)
    print("Soma de Y² (ΣY²):", sum_y_squared)
    
    # Criação da tabela com duas linhas
    df = pd.DataFrame({"X (variável independente)": x, "Y (variável dependente)": y})
    print("\nTabela com os valores de X e Y:")
    print(df)
    
    # Calcular o coeficiente de correlação de Pearson
    correlation_coefficient, _, _, _, _, _ = pearson_correlation(x, y)
    print("\nCoeficiente de correlação de Pearson entre X e Y:", round(correlation_coefficient, decimal_places))
    
    # Calcular o coeficiente de determinação
    r_squared, _, _, _, _, _ = coefficient_of_determination(x, y)
    print("Coeficiente de determinação (R²) entre X e Y:", round(r_squared, decimal_places), "%")
    
    # Calcular a reta de regressão
    slope, intercept = regression_line(x, y)
    
    # Mostrar a equação da reta
    equation = format_equation(slope, intercept)
    print("\nEquação da reta de regressão:", equation)
    
    # Plotar o gráfico
    plt.figure(figsize=(8, 6))
    plt.scatter(x, y, color='blue', label='Dados')
    plt.plot(x, slope * x + intercept, color='red', label='Reta de Regressão')
    plt.xlabel('X')
    plt.ylabel('Y')
    plt.title('Gráfico de dispersão com Reta de Regressão')
    plt.legend()
    plt.grid(True)
    plt.show()

if __name__ == "__main__":
    main()
